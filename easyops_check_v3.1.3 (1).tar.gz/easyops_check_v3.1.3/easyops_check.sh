#!/bin/bash

echo "==============【组件说明】============================="
inner_ip=`/usr/local/easyops/deploy_init/tools/get_env.py common inner_ip`
echo "【服务器IP】：$inner_ip"
echo "服务器主要核心组件："
./check_script/check_component_list.sh
echo

echo "==============【全局功能模块巡检】============================="
/usr/local/easyops/python/bin/python ./check_script/get_agent_count.py
echo
/usr/local/easyops/python/bin/python ./check_script/business_data.py
echo
/usr/local/easyops/python/bin/python ./check_script/api_interface_check.py
echo

echo "==============【操作系统巡检】=========================="
echo "【系统整体情况】"
/usr/local/easyops/python/bin/python ./check_script/host_system_check.py
echo
echo "【时钟、用户、license检查】"
./check_script/check_time_user.sh
echo
./check_script/check_db_back.sh
echo

echo "==============【组件巡检:公共组件】====================="
component_list="api_gateway clickhouse easy_core easy_tsdb ens_client gateway kafka mongodb msgsender nginx notify orientdb permission permission_service php rabbitmq receiver redis redis-sentinel easy_columndb easy_core_gateway-PF dashboard_service-PF"

for component in $component_list
do
    component_path="/usr/local/easyops/$component"
    component_pf_path="/usr/local/easyops/pfs/$component"
    if [ -d "$component_path" ] || [ -d "$component_pf_path" ]; then
        echo
        echo "【$component】"
        ./check_script/check_$component.sh
    fi
done

echo "==============【组件巡检:资源管理】====================="
cmdb_component_list="auto_detect cmdb_extend cmdb_resource cmdb_service collector_center resource_manage sync_center model-center-PF cmdb_api-PF"

for component in $cmdb_component_list
do
    component_path="/usr/local/easyops/$component"
    component_pf_path="/usr/local/easyops/pfs/$component"
    if [ -d "$component_path" ] || [ -d "$component_pf_path" ]; then
        echo
        echo "【$component】"
        ./check_script/check_$component.sh
    fi
done

echo "==============【组件巡检:持续交付】====================="
devops_component_list="artifact container deploy deploy_repository easy_flow pipeline app_deploy_service one_ticket_service blueprint hyper-deploy-PF"

for component in $devops_component_list
do
    component_path="/usr/local/easyops/$component"
    component_pf_path="/usr/local/easyops/pfs/$component"
    if [ -d "$component_path" ] || [ -d "$component_pf_path" ]; then
        echo
        echo "【$component】"
        ./check_script/check_$component.sh
    fi
done

echo "==============【组件巡检:运维自动化】====================="
autoops_component_list="deploy inspection jobservice ops_automation scheduler scheduler_service tools tool_service"

for component in $autoops_component_list
do
    component_path="/usr/local/easyops/$component"
    if [ -d "$component_path" ]; then
        echo
        echo "【$component】"
        ./check_script/check_$component.sh
    fi
done

echo "==============【组件巡检:监控】====================="
monitor_component_list="alert_channel_go alert_service collector_proxy collector_proxy_server collector_service flink_applications flink_taskmanager flink_jobmanager flink_monitor flink_tracing metadata_center otelcol aggregate_metric_process service-observe-PF alert_metric_process apm_metric_process span_loader event_center-PF easy_process_sampler-PF collector_service-PF"

for component in $monitor_component_list
do
    component_path="/usr/local/easyops/$component"
    component_pf_path="/usr/local/easyops/pfs/$component"
    if [ -d "$component_path" ] || [ -d "$component_pf_path" ]; then
        echo
        echo "【$component】"
        ./check_script/check_$component.sh
    fi
done

echo "==============【组件巡检:IT服务中心】====================="
monitor_component_list="flowable flowable_service mysql tomcat tools"

for component in $monitor_component_list
do
    component_path="/usr/local/easyops/$component"
    if [ -d "$component_path" ]; then
        echo
        echo "【$component】"
        ./check_script/check_$component.sh
    fi
done


#  获取部署日志
if [[ -d /usr/local/ucpro/ucpro_service/data/deploy_log ]];then
           mkdir deploy_log_xunjian
           cp -a /usr/local/ucpro/ucpro_service/data/deploy_log/deploy_log-$(date +%Y)*.tar.gz ./deploy_log_xunjian
           tar -zcf deploy_log_xunjian.tar.gz deploy_log_xunjian
           rm -rf  deploy_log_xunjian
elif [[ -f /usr/local/ucpro/ucpro_service/data/release_report_log.json ]] ;then
     mkdir deploy_log_xunjian
     cp -a /usr/local/ucpro/ucpro_service/data/release_report_log.json ./deploy_log_xunjian
     cp -a /usr/local/ucpro/ucpro_service/data/release_report_event.json ./deploy_log_xunjian  >/dev/null 2>&1
     tar -zcf deploy_log_xunjian.tar.gz deploy_log_xunjian 
     rm -rf  deploy_log_xunjian
fi

#/usr/local/easyops/python/bin/python ./check_script/result_to_xls.py


