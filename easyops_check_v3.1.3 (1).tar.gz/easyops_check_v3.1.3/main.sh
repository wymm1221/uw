#!/bin/bash

echo ”开始巡检，请耐心等待...“
./easyops_check.sh > easyops_check.txt

cat  easyops_check.txt

/usr/local/easyops/python/bin/python ./check_script/result_to_xls.py

#rm -rf ./easyops_check.txt
