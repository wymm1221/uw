#!/bin/bash

#时钟同步检查
function check_time() {

local_ip=`/usr/local/easyops/deploy_init/tools/get_env.py common inner_ip`
console_ip=`/usr/local/easyops/ens_client/tools/get_all_service.py logic.next_console_service.console | head -n 1 | awk '{print $2}'`
info=`curl -X GET -H "Content-Type: application/json" -H "user: easyops" http://${console_ip}:8182/api/next_console_service/v1/console/cluster/info 2>/dev/null`
#time_info=`echo $info | sed 's/ip/\n/g' | grep ${local_ip} | awk -F ":" '{print $4}' | awk -F "," '{print $1}'`
time_info=`echo $info |  sed 's/ip/\n/g' | grep  ${local_ip}  | awk -F "timeOffset" '{print $2}'  | awk -F ":" '{print $2}' | awk -F "," '{print $1}'`
if [[ $time_info -eq 0 ]];then 
	echo  -e "时钟同步:(\033[32m正常\033[0m);"
else 
	echo  -e "时钟同步:(\033[31m异常\033[0m);"

fi
}

#easyops 密码过期检查
function check_password() {
pass_expires=`chage -l easyops | grep "Password expires" |awk -F ":" '{print $2}'`
echo -e "easyops密码过期时间为:(\033[32m$pass_expires\033[0m);"
}

# license过期检查
function check_license() {
grep -q Host-ID /usr/local/easyops/etc/easyops.lic
if [ $? -ne 0 ];then 
	echo -e "license过期时间为( $(cat /usr/local/easyops/etc/easyops.lic | base64 -d | grep ^Expires | awk -F "=" '{print $2}') );"
	echo -e "license中接入主机数量( $(cat /usr/local/easyops/etc/easyops.lic | base64 -d | grep ^DeviceNum | awk -F "=" '{print $2}') );"
else 
	echo -e "license过期时间为( $(cat /usr/local/easyops/etc/easyops.lic  | grep ^Expires | awk -F "=" '{print $2}') );"
	echo -e "license中接入主机数量( $(cat /usr/local/easyops/etc/easyops.lic  | grep ^DeviceNum | awk -F "=" '{print $2}') );"
fi
}

# 获取平台发行版本 
function check_release_version() {

cat /usr/local/easyops/deploy_init/release_version.json | grep DistributionVersion >/dev/null 2>&1
if [[ $? -eq 0  ]];then
	echo -e "平台发行版本( $(cat /usr/local/easyops/deploy_init/release_version.json  | awk -F ":" '{print $3}' | awk -F "," '{print $1}') );"
else
	echo "平台版本太低，无/usr/local/easyops/deploy_init/release_version.json文件，获取不到信息"
fi	

}

# 获取平台domain版本
function check_domain_version() {

cat /usr/local/easyops/deploy_init/release_version.json | grep domain-resource-management >/dev/null 2>&1
if [[ $? -eq 0  ]];then
        echo -e "平台domain版本( $(cat /usr/local/easyops/deploy_init/release_version.json  |grep domain-resource-management | awk -F "domain-resource-management" '{print $2}' |  awk -F ":" '{print $2}' | awk -F "," '{print $1}') );"
else
        echo "未获取到domian版本信息"
fi
}



# Logic Operation
function main() {
	if [ -f "/usr/local/easyops/etc/easyops.lic" ]; then
		check_time
		#check_password
		os_release=`/usr/local/easyops/python/bin/python  -c "import platform;print ' '.join(platform.linux_distribution()).strip() or platform.platform()"`
	        echo -e "操作系统版本( $os_release );"
                check_release_version
                check_domain_version
		check_license
		
	fi	
}

main
exit $?
