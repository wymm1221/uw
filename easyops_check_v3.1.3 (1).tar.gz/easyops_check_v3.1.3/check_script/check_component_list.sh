#!/bin/bash
#判断组件是否存在
#公共组件
public_component_list="api_gateway clickhouse easy_core easy_tsdb ens_client gateway kafka mongodb msgsender ngnix notify orientdb permission permission_service php rabbitmq receiver redis redis-sentinel easy_columndb easy_core_gateway-PF dashboard_service-PF"
public_component_res=""
for component in $public_component_list
do
    component_path="/usr/local/easyops/$component"
    if [ -d "$component_path" ]; then
        public_component_res="$public_component_res $component;"
    fi
done
echo "【公共组件】：$public_component_res"

#资源管理
cmdb_component_list="auto_detect cmdb_resource cmdb_service cmdb_extend collector_center resource_manage sync_center model-center-PF cmdb_api-PF"
cmdb_component_res=""
for component in $cmdb_component_list
do
    component_path="/usr/local/easyops/$component"
    if [ -d "$component_path" ]; then
        cmdb_component_res="$cmdb_component_res $component;"
    fi
done
echo "【资源管理】：$cmdb_component_res"

#持续交付
devops_component_list="artifact container deploy deploy_repository easy_flow pipeline app_deploy_service one_ticket_service blueprint hyper-deploy-PF"
devops_component_res=""
for component in $devops_component_list
do
    component_path="/usr/local/easyops/$component"
    if [ -d "$component_path" ]; then
        devops_component_res="$devops_component_res $component;"
    fi
done
echo "【持续交付】：$devops_component_res"

#运维自动化
autoops_component_list="deploy inspection jobservice ops_automation scheduler tools tool_service"
autoops_component_res=""
for component in $autoops_component_list
do
    component_path="/usr/local/easyops/$component"
    if [ -d "$component_path" ]; then
        autoops_component_res="$autoops_component_res $component;"
    fi
done
echo "【运维自动化】：$autoops_component_res"

#监控
monitor_component_list="alert_channel_go alert_service collector_proxy collector_proxy_server collector_service flink_applications flink_jobmanager flink_monitor flink_tracing metadata_center otelcol aggregate_metric_process service-observe-PF alert_metric_process apm_metric_process span_loader event_center-PF easy_process_sampler-PF collector_service-PF"
monitor_component_res=""
for component in $monitor_component_list
do
    component_path="/usr/local/easyops/$component"
    if [ -d "$component_path" ]; then
        monitor_component_res="$monitor_component_res $component;"
    fi
done
echo "【监控组件】：$monitor_component_res"

#IT服务中心
itsm_component_list="flowable flowable_service mysql tomcat tools"
itsm_component_res=""
for component in $itsm_component_list
do
    component_path="/usr/local/easyops/$component"
    if [ -d "$component_path" ]; then
        itsm_component_res="$itsm_component_res $component;"
    fi
done
echo "【IT服务中心】：$itsm_component_res"
