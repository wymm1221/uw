#!/usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-
import sys
import json
import requests
import sys
import socket
import yaml
import re
reload(sys)
sys.setdefaultencoding( "utf-8" )

headers = {
    "content-Type": "application/json",
    "user": "easyops",
}

def get_org():
    filename = "/usr/local/easyops/deploy_init/easy_env.ini"
    with open(filename, "r") as f:
        easy_env_res = f.read().strip()
        org_info = re.findall(r'org =(.*)',easy_env_res)[0].strip()
    if not org_info:
        print "get org error"
        sys.exit(1)
    return org_info

def get_server_ips(cmdb_port):
    filename = "/usr/local/easyops/agent/easyAgent/conf/conf.yaml"  # linux
    host = []
    with open(filename, "r") as f:
        ret_dict = yaml.load(f)
        host = ret_dict["command"]["server_groups"][0]['hosts'][0]['ip']
        host = re.split("\s*,\s*", host)
    try:
        host = [(ip, int(cmdb_port)) for ip in host]
    except Exception, e:
        print "get host ips: {0} {1} error".format(cmdb_port, host)
        sys.exit(1)
    return host

def get_available_server_ip_and_port(cmdb_port=80):
    host_ips = get_server_ips(cmdb_port)
    for ip_port in host_ips:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(3)
        result = s.connect_ex(ip_port)
        if result == 0:
            s.close()
            return ip_port
    else:
        print "get server IP Failed by port:{0}".format(cmdb_port)
        s.close()
        return ()

class CMDBAPI():
    def cmdb_instance_search(self, object_id, params):
        url = "http://{0}/object/{1}/instance/_search".format(CMDB_IP, object_id)
        ret_list = []
        count = 0
        page = 1
        page_size = 200
        # 设置查询条件
        while (count >= 0):
            count = 0
            params["page"] = page
            params["page_size"] = page_size
            headers["host"] = "cmdb_resource.easyops-only.com"
            ret = requests.post(url, headers=headers, data=json.dumps(params)).json()
            if ret["code"] == 0:
                ret_list += ret['data']['list']
                count = len(ret['data']['list']) - page_size
                page += 1
            else:
                print ret
                break
        return ret_list
CMDB = CMDBAPI()

def get_host_agent_result():
    agent_status_count_dict = {}
    params = {
        "fields":{
            "agentVersion":1,
            "_agentStatus":1,
            "osSystem":1
        }
    }
    host_result_list = CMDB.cmdb_instance_search("HOST", params)
    for host_result_info in host_result_list:
        agentStatus = host_result_info.get("_agentStatus") or u"无"
        osSystem = host_result_info.get("osSystem") or u"无"
        if agent_status_count_dict.get(agentStatus):
            agent_status_count_dict[agentStatus]["count"] += 1
            if agent_status_count_dict[agentStatus]["osSystem"].get(osSystem):
                agent_status_count_dict[agentStatus]["osSystem"][osSystem] += 1
            else:
                agent_status_count_dict[agentStatus]["osSystem"][osSystem] = 1
        else:
            agent_status_count_dict[agentStatus] = {
                "count":1,
                "osSystem":{
                    osSystem : 1
                }
            }	
    return len(host_result_list),agent_status_count_dict
    
if __name__ == "__main__":
    server_addrPair = get_available_server_ip_and_port()
    if not len(server_addrPair):
        logger.error("cant get server ip")
        sys.exit(1)
    CMDB_IP = server_addrPair[0] + ":" + str(server_addrPair[1])
    
    org_info = get_org()
    headers["org"] = org_info
    
    host_count,agent_status_count_dict = get_host_agent_result()
    #print u"Agent状态统计(主机总数:{0})".format(host_count)
    print u"【Agent状态统计】(主机总数:{0})".format(host_count)
    for agentStatus in agent_status_count_dict.keys():
        system_count_list = []
        count = agent_status_count_dict.get(agentStatus).get("count")
        for osSystem in agent_status_count_dict.get(agentStatus).get("osSystem"):
            system_count_list.append("{0}:{1}".format(osSystem,agent_status_count_dict.get(agentStatus).get("osSystem").get(osSystem)))
        #print " 【状态】：{0},【总数】：{1},【操作系统】{2}".format(agentStatus,count,";".join(system_count_list))
        if agentStatus == "异常": 
           agentStatus = "不正常"
        print " 状态：{0}({2})".format(agentStatus,count,";".join(system_count_list))

