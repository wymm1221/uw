#!/bin/bash
process_name="clickhouse"
keyword="clickhouse"
ens_name_list="data.clickhouse"

cpu_threshold=90
mem_threshold=60

function byte_unit_trans() {
    bytes=${1:?"bytes is empty"}
    echo ${bytes}|awk -v b=${bytes} 'b>1000000{print b/1024/1024"GB";next}b>1000{print b/1024"MB";next}{print b"KB"}'
}

function compare() {
    condition=$1
    [[ `echo $1|bc` -ge 1 ]] && return 0 || return 1
}

function check_app_use(){
words=$( ps aux 2>/dev/null |grep -Pi "${keyword}"|grep -vP "grep -Pi|$$|$0" |awk  '{cpu+=$3} {mem+=$4} {pid=pid","$2} {pid_count+=1} END{print cpu, mem, pid, pid_count}')
if [ -z "${words}" ];then
    echo "process is not found with the keyword '${keyword}'"
    exit 1
else
    ps_info=(${words})
	cpu_use=${ps_info[0]}
    mem_use=${ps_info[1]}
	cpu_usge_int=`echo ${cpu_use%.*}`
        mem_usge_int=`echo ${mem_use%.*}`
	if [[ $mem_usge_int -gt $mem_threshold ]];then
        mem_usge="内存使用率异常(\033[31m$mem_use%\033[0m)"
    else
		mem_usge="内存使用率正常(\033[32m$mem_use%\033[0m);"
    fi
	
	if [[ $cpu_usge_int -gt $cpu_threshold  ]];then
        cpu_usge="cpu使用率异常(\033[31m$cpu_use%\033[0m);"
    else
        cpu_usge="cpu使用率正常(\033[32m$cpu_use%\033[0m);"
    fi
fi
}

function check_ens(){
    name_service_status="(\033[32m正常\033[0m);"
	for ens_name in $ens_name_list
	do
	    /usr/local/easyops/ens_client/tools/get_all_service.py $ens_name > /dev/null
	    if [ $? -ne 0 ];then
	        name_service_status="(\033[31m异常\033[0m);"
		    #echo "get name service error: $ens_name"
	    fi
    done
}

function check_app_health(){
    easyops status /usr/local/easyops/$process_name | grep "\[ok\]" > /dev/null 
	if [[ $? -eq 0 ]];then
		#echo -e "组件健康状态正常(\033[32mok\033[0m);"
		process_status="(\033[32mok\033[0m);"
	else
		echo -e "组件健康状态异常(\033[31merror\033[0m);"
		process_status="error"
	fi	
}
function check_cluster_status(){
    clickhouse_password=`/usr/local/easyops/deploy_init/tools/get_env.py clickhouse password`
    #/usr/local/easyops/clickhouse/bin/clickhouse-client --host 127.0.0.1 --port 9800 --user easyops --password $clickhouse_password --multiquery --query "select * from system.clusters;"
	errors_count_info=`/usr/local/easyops/clickhouse/bin/clickhouse-client --host 127.0.0.1 --port 9800 --user easyops --password $clickhouse_password --query "select errors_count from system.clusters;" 2>/dev/null`
	errors_count=0
	for errors_info in $errors_count_info
	do
	    errors_count=$(expr ${errors_count} + ${errors_info})
	done
	
	if [[ $errors_count -eq 0 ]];then
	    echo -e "集群状态正常(\033[32mok\033[0m);"
	    #easy_core_cluster_status="error"
	else
	    echo -e "集群状态异常(\033[31merror\033[0m);"
	    #easy_core_cluster_status="ok"
	fi
}

DIR="/usr/local/easyops/$process_name"
if [ -d "$DIR" ]; then

            status=`easyops status /usr/local/easyops/$keyword | grep "not a valid package\|status:"`
                printf "%-10s%-10s\n" "$keyword检查结果: "
                        # 状态为ok并且start的则进行CPU内存判断
                        if [[ $status =~ "ok" ]] && [[ $status =~ "started" ]]; then

                           check_ens
                           #       check_app_health
                           #check_cluster_status
                           check_app_use
                echo -e "名字服务：$name_service_status $cpu_usge $mem_usge 组件健康状态正常(\033[32mok\033[0m);"$(check_cluster_status)
                        elif [[ $status =~ "current path is not a valid package" ]]; then
                                echo -e "组件健康状态正常(\033[32m该目录是一个未easyops init后的目录，不需要关注\033[0m);"
                        elif [[ $status =~ "ok" ]] && [[ $status =~ "stopped" ]]; then

                                echo -e "组件健康状态异常，status为(\033[31mok stopped状态是人工停止的状态，可以忽略),请确
认;"


                        else
                                echo -e "组件健康状态异常，status为(\033[31m$status\033[0m),请确认。"
                        fi

        fi

