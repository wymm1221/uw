#!/usr/local/easyops/python/bin/python
# coding:utf-8
import json
import requests
import os
import sys
import io
import datetime

# reload(sys)
# sys.setdefaultencoding("utf-8")


def print_(j,format_=True):
    if format_:
        print json.dumps(j,ensure_ascii=False,indent=2)
    else:
        print json.dumps(j,ensure_ascii=False)


class CMDBAPI:
    # 初始化，传入cmdb ip和org
    def __init__(self, org=None, ip=None):
        if not org:
            print "未获取到org"
        if not ip:
            print "未获取到ip"
        else:
            self.ip = ip
        self.headers = {
            "user": "easyops",
            #"host": "cmdb_resource.easyops-only.com",
            "org": str(org)
        }
    # 自定义cmdbapi请求

    def custom_req(self, method, url, data=None, files=None, params=None):
        url = 'http://{0}:{1}'.format(self.ip, url)
        #print url
        res = requests.request(method=method, url=url, data=json.dumps(
            data), files=files, params=params, headers=self.headers)
        return res

    # 查询cmdb数据

    def serach_cmdb_data(self, ):
        url = "8182/api/v1/next_console/CmdbStat"

        ret = self.custom_req('get', url)
        if ret.status_code == 200:
            content = json.loads(ret.text)
            print "【资源管理】"
            print "模型数量({0})".format(content["data"]["objectTotal"])
            return ret.status_code, ret.text

    # 查询持续交付数据
    def serach_devops_data(self, ):
        url = "8182/api/v1/next_console/DevOpsStat"

        ret = self.custom_req('get', url)
        if ret.status_code == 200:
            content = json.loads(ret.text)
            #print content
            print "【持续交付】"
            print "应用数量({0})".format(content["data"]["appTotal"])
            print "程序包数量({0})".format(content["data"]["packageTotal"])
            #print "部署实例数({0})".format(content["data"]["appTotal"]))
            print "部署实例数({0})".format(content["data"]["deployInstanceTotal"])
            return ret.status_code, ret.text

    # 查询包版本数据
    def serach_devops_version(self, ):
        #ip = '10.250.95.19'
        ip = os.popen("/usr/local/easyops/ens_client/tools/get_all_service.py logic.artifact | awk '{print $2}' | tail -1").read().strip()
        url = "http://{0}:8175/version/list".format(ip)
        ret = requests.request(method="get", url=url, headers=self.headers)
        if ret.status_code == 200:
            content = json.loads(ret.text)
            print "程序包版本总量({0})".format(content["data"]["total"])
            return ret.status_code, ret.text

    # 查询运维自动化数据
    def serach_autoops_data(self, ):
        url = "8182/api/v1/next_console/AutoOpsStat"

        ret = self.custom_req('get', url)
        if ret.status_code == 200:
            content = json.loads(ret.text)
            # print content)
            print "【运维自动化】"
            print "工具数量({0})".format(content["data"]["autoOpsToolTotal"])
            print "流程数量({0})".format(content["data"]["autoOpsFlowTotal"])
            print "定时任务数({0})".format(content["data"]["autoOpsSchedulerTotal"])
            print "作业数({0})".format(content["data"]["autoOpsActionTotal"])
            return ret.status_code, ret.text

    # 查询智能监控数据
    def serach_monitor_data(self, ):
        url = "8182/api/v1/next_console/MonitorStat"

        ret = self.custom_req('get', url)
        if ret.status_code == 200:
            content = json.loads(ret.text)
            # print content)
            print "【智能监控】"
            print "监控资源数({0})".format(content["data"]["monitorObjectTotal"])
            print "采集任务/策略数({0}/{1})".format(content["data"]["monitorCollectorJobTotal"], content["data"]["monitorAlertRuleTotal"])
            print "指标数({0})".format(content["data"]["monitorMetricTotal"])
            print "采集插件数({0})".format(content["data"]["monitorPluginTotal"])
            print "Dashboard数({0})".format(content["data"]["monitorDashboardTotal"])
            return ret.status_code, ret.text

    # 查询IT服务中心数据
    def serach_itsc_data(self, ):
        url = "8182/api/v1/next_console/ItscStat"

        ret = self.custom_req('get', url)
        if ret.status_code == 200:
            content = json.loads(ret.text)
            # print content)
            print "【IT服务中心】"
            print "服务数({0})".format(content["data"]["itscServiceTotal"])
            print "流程数({0})".format(content["data"]["itscProcessTotal"])
            return ret.status_code, ret.text
    # 导出bussines 数据
    def exprot_bussnies_data(self, ):
        url = "8182/api/next_console_service/v1/console/export/data"
        

        ret = self.custom_req('get', url)
        if ret.status_code == 200:
            content = json.loads(ret.text)
            dir_path = os.getcwd()
            #print(dir_path)
            f = io.open("{0}/bussniess_data_{1}_{2}.json".format(dir_path, local_ip, now),'w', encoding='utf-8')
            f.write(json.dumps(content.get("data"), ensure_ascii=True).decode('utf8'))
            f.close()
            #print(content)
            return ret.status_code, ret.text


if __name__ == "__main__":
    #org=3968326
    #ip='10.250.95.19'
    ip = os.popen("/usr/local/easyops/ens_client/tools/get_all_service.py logic.next_console_service.console | sort -n | awk '{print $2}'| tail -1").read().strip()
    org = os.popen("cat /usr/local/easyops/deploy_init/easy_env.ini | grep org | grep -v '#' | awk '{print $3}'").read().strip()
    local_ip = os.popen("/usr/local/easyops/deploy_init/tools/get_env.py common inner_ip").read().strip()
    now = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    #print ip
    api = CMDBAPI(org=org, ip=ip)
    try:
      api.serach_cmdb_data()
    except:
      print("调用cmdb运营数据接口未获取到数据")
    try:
      api.serach_devops_data()
    except:
      print("调用devops运营数据接口未获取到数据")
    try:
      api.serach_devops_version()
    except:
      print("调用包版本接口未获取到数据")
    try:
      api.serach_autoops_data()
    except:
      print("调用autoops运营数据接口未获取到数据")
    try:
      api.serach_monitor_data()
    except:
      print("调用monitor运营数据接口未获取到数据")
    try:
      api.serach_itsc_data()
    except:
      print("调用itsc运营数据接口未获取到数据")
    if ip =="127.0.0.1" or ip == local_ip:
      #print("console host")
      try:
        api.exprot_bussnies_data()
      #except Exception as e:
        #print(e)
      except:
        print("调用bussniess数据接口未获取到数据")

