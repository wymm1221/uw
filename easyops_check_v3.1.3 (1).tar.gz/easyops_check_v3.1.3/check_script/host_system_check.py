#!/usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-
import sys
import json
import requests
import sys
import socket
import yaml
import re
import os
import psutil
import subprocess
reload(sys)
sys.setdefaultencoding( "utf-8" )

def do_cmd(cmd,shell=True, err=False):
    output = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    output.wait()
    if output.returncode != 0:
        raise SystemError('执行命令 %s 失败！' % cmd)
    else:
        if err:
            return False,output.stderr.read()
        return True,output.stdout.read()

def get_cpu_info():
    host_cpu_used_total = int(psutil.cpu_percent(interval=3))
    host_cpu_count = int(psutil.cpu_count())
    return host_cpu_used_total,host_cpu_count

def get_load_info():
    load_res_list = os.getloadavg()
    load_result = {'host.load.1': load_res_list[0], 'host.load.5': load_res_list[1], 'host.load.15': load_res_list[2]}
    return load_result

def get_mem_info():
    virtual_memory = psutil.virtual_memory()
    swap_memory = psutil.swap_memory()
    # 在lxc机器，psutil<5.0版本，内存得到的是母机的
    # 5.4.3 以上的版本计算方式
    # used = total - free - cached - buffers
    # if used < 0:
    #     used = total - free

    # 4.3.0 的计算方式
    # used = total - free
    cached = getattr(virtual_memory, 'cached', 0)
    buffers = getattr(virtual_memory, 'buffers', 0)
    free = getattr(virtual_memory, 'free', 0)
    total = getattr(virtual_memory, 'total', 1)

    available = getattr(virtual_memory, 'available', 0)
    if available > 0:
        percent = float(total - available) / float(total) * 100
    else:
        percent = float(total - free - buffers - cached) / float(total) * 100

    data = {
        'host.mem.free': free / 1024,
        'host.mem.total': total / 1024,
        'host.mem.cached': cached / 1024,
        'host.mem.buffers': buffers / 1024,
        'host.mem.percent': percent,
        'host.mem.available': available / 1024,
        'host.mem.used': getattr(virtual_memory, 'used', 0) / 1024,
        'host.mem.swap_total': getattr(swap_memory, 'total', 0) / 1024,
        'host.mem.swap_used': getattr(swap_memory, 'used', 0) / 1024,
        'host.mem.swap_free': getattr(swap_memory, 'free', 0) / 1024,
        'host.mem.swap_percent': getattr(swap_memory, 'percent', 0),
    }
    return data
    
def convert_to_int(value, default=0):
    if value.isdigit():
        return int(value)
    else:
        return default

def get_disk_info():
    retdict = {}
    host_data = {
        'host.disk.max_used_percent': 0,
        'host.disk.max_used_percent_mount': '',
        'host.disk.used_percent': 0,
        'host.disk.used': 0,
        'host.disk.free': 0,
        'host.disk.total': 0,
    }

    partitions = psutil.disk_partitions()
    for partition in partitions:
        if 'cdrom' in partition.opts.lower():
            continue
        if 'removable' in partition.opts.lower():
            continue
        # 光盘
        if partition.fstype.lower() in ['hsf', 'iso9660', 'iso13490', 'udf']:
            continue
        # 虚拟分区
        if partition.fstype.lower() in ['configfs', 'devfs', 'debugfs', 'kernfs', 'procfs', 'specfs', 'sysfs',
                                        'tmpfs', 'winfs']:
            continue
        # custom
        if partition.fstype.lower() in ['proc', 'binfmt_misc', 'devpts']:
            continue

        mountpoint = partition.mountpoint
        usage = psutil.disk_usage(mountpoint)
        if usage.percent > host_data['host.disk.max_used_percent']:
            host_data['host.disk.max_used_percent'] = usage.percent
            host_data['host.disk.max_used_percent_mount'] = mountpoint
        host_data['host.disk.used'] += usage.used
        host_data['host.disk.free'] += usage.free
        host_data['host.disk.total'] += usage.total

        adisk = dict()
        adisk['host.disk.used_per'] = usage.used >> 10
        adisk['host.disk.free_per'] = usage.free >> 10
        adisk['host.disk.total_per'] = usage.total >> 10
        adisk['host.disk.used_percent_per'] = usage.percent
        dim = {'name': 'host_disk', 'mountpoint': mountpoint}
        retdict[mountpoint] = (dim, adisk)

    host_data['host.disk.used_percent'] = 0
    if host_data['host.disk.total']:
        percent = host_data['host.disk.free'] * 100 / host_data['host.disk.total']
        host_data['host.disk.used_percent'] = 100 - percent
    host_data['host.disk.used'] >>= 10
    host_data['host.disk.free'] >>= 10
    host_data['host.disk.total'] >>= 10

    return host_data
        
if __name__ == "__main__":
    #CPU使用率
    host_cpu_used_total,host_cpu_count = get_cpu_info()
    
    load_info_dict = get_load_info()
    #15分钟负载
    host_load_15 = load_info_dict.get("host.load.15")
    
    mem_info_dict = get_mem_info()
    #内存大小
    host_mem_total = int(mem_info_dict.get("host.mem.total"))/1024/1024
    #内存使用率
    host_mem_percent = mem_info_dict.get("host.mem.percent")
    #可用内存
    host_mem_available = int(mem_info_dict.get("host.mem.available"))/1024/1024
    
    disk_info_dict = get_disk_info()
    host_disk_total = disk_info_dict.get("host.disk.total")/1024/1024
    host_disk_used_percent = disk_info_dict.get("host.disk.used_percent")
    hostname = os.popen('hostname').read().strip()
    #ip = os.popen("hostname -I | awk '{print $1}'").read().strip()
    ip = os.popen("/usr/local/easyops/deploy_init/tools/get_env.py common inner_ip").read().strip()
    oom = os.popen('cat /var/log/messages | grep -i "out of memory" | wc -l').read().strip()
    if int(oom) > 0:
        oom = "oom次数异常{}".format(oom)
    if int(host_load_15) > int(host_cpu_count):
        host_load_15 = "cpu负载异常{}".format(host_load_15)
    if float(host_cpu_used_total) > 90:
        host_cpu_used_total = "cpu使用率{}%,超过90%异常".format(host_cpu_used_total)
    else:
        host_cpu_used_total = "{}%".format(host_cpu_used_total)
    if float(host_mem_percent) > 90 and int(host_mem_available) < 5:
        host_mem_percent = "内存使用率{}%,超过90%异常，并且小于5G".format(host_mem_percent)
    else:
        host_mem_percent = "{}%".format(round(host_mem_percent,2))
    if float(host_disk_used_percent) > 95:
        host_disk_used_percent = "磁盘使用率{}%,超过95%异常".format(host_disk_used_percent)
    else:
        host_disk_used_percent = "{}%".format(host_disk_used_percent)

        #print "主机名:{8}, IP地址:{9}, CPU核数:{0}，CPU使用率:{1}%，15分钟平均负载:{2}，内存大小:{3}GB，内存使用率:{4}%，可用内存:{5}GB，磁盘大小:{6}GB，磁盘使用率:{7}%, oom次数:{10}".format(host_cpu_count,host_cpu_used_total,host_load_15,host_mem_total,round(host_mem_percent,2),host_mem_available,host_disk_total,host_disk_used_percent, hostname, ip, oom)
    print "主机名({8}); IP地址({9}); CPU核数({0});CPU使用率({1});15分钟平均负载({2});\n内存大小({3}GB);内存使用率({4});\n可用内存({5}GB);磁盘大小({6}GB);磁盘使用率({7}); oom次数({10});".format(host_cpu_count,host_cpu_used_total,host_load_15,host_mem_total,host_mem_percent,host_mem_available,host_disk_total,host_disk_used_percent, hostname, ip, oom)
   

