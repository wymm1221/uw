#!/bin/bash

# easy_core和mongodb的备份检查

org=`cat /usr/local/easyops/deploy_init/easy_env.ini | grep org | grep -v "#" | awk  '{print $3}'`
mongo_backupdir1="/data/BackupDB/mongo"
mongo_backupdir2="/data/easyops/mongodb/backup"
easycore_backupdir="/data/easyops/easy_core/data/backup/${org}"
mysql_backupdir="/data/BackupDB/mysql"

#mongodb备份检查
function mongodb_backup() {
        d1=`date "+%Y%m%d"`
        d2=`date -d '1 days ago' +%Y%m%d`
        d3=`date -d '2 days ago' +%Y%m%d`
    if [ ! -d $mongo_backupdir1 ];then
        mongo_backupdir=$mongo_backupdir2
    else
        mongo_backupdir=$mongo_backupdir1
    fi
        cd $mongo_backupdir
        ls -la | grep "${d1}\|${d2}\|${d3}" >/dev/null 2>&1
        if [[ $? -gt 0 ]];then
            echo -e "mongodb的备份异常，(\033[31m最近3天无备份\033[0m);"

        else
            echo -e "备份脚本路径: (/usr/local/easyops/mongodb/bin/backup.sh)"
            echo -e "备份频率: (每天)"
            echo -e "备份路径: (${mongo_backupdir})"
            echo -e "mongodb的备份，(\033[32m正常\033[0m);"
            echo -e "备份存储周期:( `ls -la ${mongo_backupdir} | grep  mongo | wc -l` );"

        fi


}


#mysql备份检查
function mysql_backup() {
        d1=`date "+%Y_%m_%d"`
        d2=`date -d '1 days ago' +%Y_%m_%d`
        d3=`date -d '2 days ago' +%Y_%m_%d`
        d4=`date "+%Y%m%d"`
        d5=`date -d '1 days ago' +%Y%m%d`
        d6=`date -d '2 days ago' +%Y%m%d`

        if [ -d "$mysql_backupdir" ]; then 
          cd $mysql_backupdir
          ls -la | grep "${d1}\|${d2}\|${d3}|${d4}\|${d5}\|${d6}" >/dev/null 2>&1
          if [[ $? -gt 0 ]];then
            echo -e "mysql的备份异常，(\033[31m最近3天无备份,请确认mysql是否正常使用，默认1.0监控和itsc模块会使用到mysql\033[0m);"

          else
                #echo -e "备份脚本路径:( /usr/local/easyops/easy_core/conf/config.default.yaml)"
                echo -e "备份频率: (每天)"
                echo -e "备份路径: (/data/BackupDB/mysql)"
                echo -e "mysql的备份，(\033[32m正常\033[0m);"
                echo -e "备份存储周期:( $(ls -la /data/BackupDB/mysql/ | grep -i backup | wc -l) );"
          fi
        else
          echo -e "mysql的备份异常，(\033[31m最近3天无备份,请确认mysql是否正常使用，默认1.0监控和itsc模块会使用到mysql\\033[0m);"
        fi

}


#easy_core备份检查
function easycore_backup() {
	d1=`date "+%Y-%m-%d"`
	d2=`date -d '1 days ago' +%Y-%m-%d`
	d3=`date -d '2 days ago' +%Y-%m-%d`
	cd $easycore_backupdir
	ls -la | grep "${d1}\|${d2}\|${d3}" >/dev/null 2>&1
	if [[ $? -gt 0 ]];then
	    echo -e "easy_core的备份异常，(\033[31m最近3天无备份\033[0m);"
	    
	else	    
		echo -e "备份脚本路径:( /usr/local/easyops/easy_core/conf/config.default.yaml)"
		echo -e "备份频率: (每天)"
		echo -e "备份路径: (/usr/local/easyops/easy_core/data/backup/)"
		echo -e "easy_core的备份，(\033[32m正常\033[0m);"
                echo -e "备份存储周期:( $(ls -la /usr/local/easyops/easy_core/data/backup/1 | grep -i backup | wc -l) );"

	fi

}


# 单机环境直接备份，集群环境: 从从库进行备份，先判断哪台机器是从库，然后在进行备份
function isCluster() {
    #获取集群配置
    cluster=$(/usr/local/easyops/deploy_init/tools/get_env.py DEFAULT is_cluster)
	echo $cluster
    if [[ $? -ne 0 ]]; then
        echo "/usr/local/easyops/deploy_init/tools/get_env.py DEFAULT is_cluster failed"
        exit 1
    fi
    echo $cluster
}


# 如果是集群模式 且为从节点直接备份
function isMaster() {
	/usr/local/easyops/mongodb/bin/mongo --eval "printjson(db.isMaster())" | grep "ismaster\|secondary" | grep true  >/dev/null 2>&1
    if [[ $? -eq 0 ]]; then
      echo 'true'
    else
      echo 'false'
    fi
}


#easy_core备份检查
DIR="/usr/local/easyops/easy_core"
if [ -d "$DIR" ]; then
	echo "【easy_core备份检查】"
	easycore_backup
	echo
fi	


#mysql备份检查
DIR="/usr/local/easyops/mysql"
if [ -d "$DIR" ]; then
       status=$(easyops status /usr/local/easyops/mysql | grep "not a valid package\|status:")
        # mysql状态正常在检查备份
       if [[  $status =~ "started" ]] && [[ $status =~ "ok" ]]; then
           echo "【mysql备份检查】"
           mysql_backup
           echo
       fi
fi


#mongodb备份检查
if [ -d "/usr/local/easyops/mongodb" ]; then
	# 如果是单机模式 直接备份
	if [[ $(isCluster) == 'false' ]]; then
	  echo "【mongodb备份检查】"
	  mongodb_backup
	else
	  if [[ $(isMaster) == 'true' ]]; then
	        echo "【mongodb备份检查】"
		mongodb_backup
	  fi
	fi
	echo
fi	
