# _*_coding: utf-8_*_
import requests
import json
import datetime
import sys
import shutil
#import xlsxwriter
import os
import re
import warnings
import yaml
dir_path = os.getcwd()
reload(sys)
sys.setdefaultencoding('utf-8')
sys.path.append("{0}/check_script/py_package".format(dir_path))
import xlsxwriter
#yaml.warnings({'YAMLLoadWarning':False})

ip = os.popen("/usr/local/easyops/deploy_init/tools/get_env.py common inner_ip").read().strip()

with open( "{0}/easyops_check.txt".format(dir_path), 'rb') as f:
    #替换颜色字符
    context = (f.read().decode("UTF-8").replace("\033[31m","").replace("\033[32m","").replace("\033[0m",""))

#处理easy_core和mongodb多行文本的格式
#context = re.sub(r'(org\s+模型id\s+实例数量)', r'(\1', context)
#context = re.sub(r'(耗时\s*执行时间)', r'(\1', context)
context = context.replace("org		模型id				实例数量", "(org      模型id      实例数量")
context = context.replace("耗时		执行时间", "(耗时            执行时间")
context = re.sub(r'(\d+\s+\S+\s+\d+)', r'(\1', context)
context = re.sub(r'(\d+ms\s+\S+\s+I\s+COMMAND\s+\S+)', r'(\1', context)
context = re.sub(r'(\S+\s+\d+\.\d+GB)', r'(\1', context)


#print os.getcwd() #获取当前工作目录路径

#print u"    获取到巡检数据:{0}".format(len(result_list))
now = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
#dir_path = "/data/easyops_check_v2.6/easyops_check/"
#dir_path = os.getcwd()
file_name = "/{0}_cruiser_info_{1}.xlsx".format(ip, str(now))

# if os.path.isdir(dir_path):
#     print(u"清理目录下文件:{0}".format(dir_path))
#     shutil.rmtree(dir_path,True)

# 生成新的目录
if not os.path.isdir(dir_path):
    os.makedirs(dir_path)
file_path = dir_path + file_name

wb2007 = xlsxwriter.Workbook(file_path)
format_top = wb2007.add_format({'border': 1, 'bold': True})  #加粗
#format_other = wb2007.add_format({'border': 1, 'valign': 'vcenter', 'text_wrap': True})
format_other = wb2007.add_format({'border': 1, 'valign': 'vcenter'})
format_red = wb2007.add_format({'border': 1, 'valign': 'vcenter', 'color': 'red'}) #红色

worksheet_abnormol = wb2007.add_worksheet("本节点异常项")
worksheet_distribute = wb2007.add_worksheet("本节点组件分布")
worksheet_abnormol.set_column(0, 100, 30)
worksheet_distribute.set_column(0, 1, 30)
worksheet_distribute.set_column(1, 10, 100)

result_list = context.split("==============【")
#print(u"    获取到巡检数据:{0}".format(len(result_list)))
row_abnomoal = 0
n1 = 0
for line_result in result_list:
    if line_result.find("】==") > -1 and line_result.find("组件说明") == -1:
        #创建sheet
        worksheet2007 = wb2007.add_worksheet(line_result.split("\n")[0].split("】==")[0].replace(":","_"))
        # 设置sheet单元格宽度
        worksheet2007.set_column(1, 100, 30)


        # 组件节点分布统计
        # 组件说明和agent统计 格式化
        if line_result.find("组件说明") > -1 or line_result.find("全局功能模块巡检") > -1 :
            line_result = line_result.replace(";", "、").replace("】：", "】;")
        elif line_result.find("操作系统巡检") == -1 and line_result :

            worksheet_distribute.write(n1, 0, line_result.split("】====")[0].split(":")[1], format_top)
            res=""
            for context in line_result.split("】====")[1].split("】\n"):
                if context.find("【") > -1:
                    res += context.split("【")[1] +"、"
            if not res:
                res = "本节点未部署此模块的组件"
            worksheet_distribute.write(n1, 1, res)
            n1 += 1


        row = 0
        # 以【分割获取不同组件的内容
        # print("debug---"+line_result)
        for lines in line_result.split("【"):
            #print("debug2----"+lines)
            # 异常sheet写入
            if lines.find("异常") > -1:
                # worksheet_abnormol.write(row_abnomoal, 0, str(lines.split("】")[0]), format_red)
	            #print("【{}】".format(str(lines.split("】")[0])))
                for lines_abnomoal in lines.split("\n"):
                    for line_abnomoal in lines_abnomoal.split(";"):
                        if line_abnomoal.find("异常") > -1:
			                 #print(line_abnomoal)
                            worksheet_abnormol.write(row_abnomoal, 0, str(lines.split("】")[0]), format_red)
                            worksheet_abnormol.write_row(row_abnomoal, 1, line_abnomoal.replace(")","").split("("), format_red)
                            row_abnomoal += 1
            # #组件节点分布统计
            # # 组件说明和agent统计 格式化
            # if lines.find("组件说明") > -1 or lines.find("agent统计") > -1:
            #     lines = lines.replace(";", "、").replace("】：", "】;")
            # elif lines.find("操作系统巡检") == -1:
            #     print("debugwy---"+lines)
            #     worksheet_distribute.write(n1, 0, lines.split("】")[0], format_top)
            #     res=""
            #     for context in lines.split("】")[1].split("】\n"):
            #         if context.find("【") > -1:
            #             print(type(context.split("【")[1]))
            #             print(context)
            #             res += context.split("【")[1] +"、"
            #     worksheet_distribute.write(n1, 1, res)
            #     n1 += 1


            # 按照行分割，过滤一些不需要展示的行
            for line in lines.split("\n"):
                if line.find("】==") > -1 or line.find("检查结果") > -1:
                    continue

                #以;分割获取每个组件不同的巡检项
                for res in line.split(";"):
                    #添加第一列具体的组件
                    if res.find("】") > -1 :
                        worksheet2007.write(row, 0, res.replace("】", ""), format_top)

                    # 过滤空行
                    elif  res.strip():
                        l1 = res.replace(")", "").split("(")

                        # 判断异常 输出红色
                        if res.find("异常") >  -1 :
                            worksheet2007.write_row(row, 1, l1, format_red)

                        else:
                            worksheet2007.write_row(row, 1, l1, format_other)
                        row += 1

wb2007.close()


print("\n")
print(u"巡检原始数据保存到文件:{0}".format(file_path))
