#!/bin/bash
keyword="deploy"

# Logic Operation
function main() {
	# 可以进入相关目录才去检查
	cd /usr/local/easyops/$keyword  >/dev/null 2>&1

	if [[ $? -eq 0 ]];then

            status=`easyops status /usr/local/easyops/$keyword | grep "not a valid package\|status:"`
                printf "%-10s%-10s\n" "$keyword检查结果: "
                        # 状态为ok并且start的则进行CPU内存判断
                        if [[ $status =~ "ok" ]] && [[ $status =~ "started" ]]; then

                                echo -e "组件健康状态正常(\033[32m状态为ok\033[0m);"
                        elif [[ $status =~ "current path is not a valid package" ]]; then
                                echo -e "组件健康状态正常(\033[32m该目录是一个未easyops init后的目录，不需要关注\033[0m);"
                        elif [[ $status =~ "ok" ]] && [[ $status =~ "stopped" ]]; then

                                echo -e "组件健康状态异常，status为(\033[31mok stopped状态是人工停止的状态，可以忽略),请确
认;"


                        else
                                echo -e "组件健康状态异常，status为(\033[31m$status\033[0m),请确认。"
                        fi

        fi

}

main
exit $?
