#!/bin/bash
keyword="flowable"
cpu_threshold=90
mem_threshold=60

function check_app_ens(){
    /usr/local/easyops/ens_client/tools/get_all_service.py logic.flowable.api >/dev/null 2>&1
	if [[ $num -eq 0 ]];then
		echo -e "名字服务正常(\033[32m状态为ok\033[0m);"
	else
		echo -e "名字服务异常(\033[31m状态为error\033[0m);"
	fi	 
}



# Logic Operation
function main() {
	# 可以进入相关目录才去检查
	cd /usr/local/easyops/$keyword  >/dev/null 2>&1

	if [[ $? -eq 0 ]];then
            status=`easyops status /usr/local/easyops/$keyword | grep "not a valid package\|status:"`
                printf "%-10s%-10s\n" "$keyword检查结果: "
                        # 状态为ok并且start的则进行CPU内存判断
                        if [[ $status =~ "ok" ]] && [[ $status =~ "started" ]]; then

                                echo -e $(check_app_ens)"组件健康状态正常，启动的进程是tomcat,进程资源占用参考tomcat,(\033[32m状态为ok\033[0m);"
                        elif [[ $status =~ "current path is not a valid package" ]]; then
                                echo -e "组件健康状态正常(\033[32m该目录是一个未easyops init后的目录，不需要关注\033[0m);"
                        elif [[ $status =~ "ok" ]] && [[ $status =~ "stopped" ]]; then

                                echo -e "组件健康状态异常，status为(\033[31mok stopped状态是人工停止的状态，可以忽略),请确
认;"


                        else
                                echo -e "组件健康状态异常，启动的进程是tomcat,进程资源占用参考tomcat,status为(\033[31m$status\033[0m),请确认。" 
                        fi

        fi

}

main
exit $?


