#!/usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-
import sys
import json
import requests
import sys
import re
import os
import time
import random


reload(sys)
sys.setdefaultencoding("utf-8")
dir_path = os.getcwd()

# cmdb 实例查询
def search_cmdb(obj_id, res_params=None):
    HEADERS = {"user": "easyops",
               "org": str(EASYOPS_ORG),
               "Content-Type": "application/json",
               "host": "cmdb_resource.easyops-only.com"
               }
    url = "http://{}:8079/v3/object/{}/instance/_search".format(cmdb_ip, obj_id)
    resp = requests.post(url=url, headers=HEADERS, json=res_params, timeout=60)
    message = resp.json()
    # if resp.status_code == 200:
    #     message = resp.json()
    return message

# cmdb 更新接口
def import_cmdb():
    HEADERS = {"user": "easyops",
               "org": str(EASYOPS_ORG),
               "Content-Type": "application/json",
               "host": "cmdb_resource.easyops-only.com"
               }
    url = "http://{}:8079/object/_TOOL_VERSION@EASYOPS/instance/_import".format(cmdb_ip)
    params = {
    "keys": [
        "vId",
        "relatedToolId"
        ],
    "datas": [
        {
            "envType": "production",
            "relatedToolId": "1dddb6dd8e49a47e5983a0363824faed",
            "vId": "7cb4437ea2fc2ed38bbe6da90557dd93"
        }
        ]
    }
    resp = requests.post(url=url, headers=HEADERS, json=params, timeout=60)
    message = resp.json()
    # if resp.status_code == 200:
    #     message = resp.json()
    return message

# 创建工具
def create_tool(tool_name):
    HEADERS = {"user": "easyops",
               "org": str(EASYOPS_ORG),
               "Content-Type": "application/json",
               }
    url = "http://{}:8181/tools".format(tool_ip)
    res_params = {
      "inputs": [
        {
          "cmdbAttrId": "ip",
          "cmdbObjectId": "HOST",
          "label": "执行目标",
          "multiple": True,
          "name": "@agents",
          "required": True,
          "type": "cmdbInstances"
        }
      ],
      "sandboxRun": False,
      "type": "shell",
      "icon": "wrench",
      "style": "default",
      "category": "默认",
      "tags": [],
      "whiteList": [],
      "blackList": [],
      "toolOutputs": {
        "dimensions": [],
        "columns": []
      },
      "outputDefs": [],
      "tableDefs": [],
      "timeout": 86400,
      "vName": "1.0.0",
      "content": "echo \"工具执行正常\"",
      "readAuthorizers": [],
      "name": tool_name,
      "batchStrategy": None,
      "defaultExecUser": "root",
      "windowsDefaultExecUser": "System",
      "windowsSession": False,
      "envLinux": [],
      "envWindows": [],
      "windowsOnlyActiveSession": False,
      "functionType": "",
      "toolLibs": []
    }

    resp = requests.post(url=url, headers=HEADERS, json=res_params, timeout=60)
    message = resp.json()
    # if resp.status_code == 200:
    #     message = resp.json()
    return message

def import_tool():

    url = "http://{}:8181/tools/import".format(tool_ip)
    #工具存放绝对路径
    tool_dir = "{}/check_script/inspection_test_tool-1.0.0.tar.gz".format(dir_path)
    payload = {}
    files = [
        ('file',
         ('inspection_test_tool-1.0.0.tar.gz', open(tool_dir, 'rb'), 'application/octet-stream'))
    ]
    headers = {
        'Host': 'tool.easyops-only.com',
        'org': str(EASYOPS_ORG),
        'user': 'easyops',
        # 'Content-Type': 'application/json'
    }
    #print url
    response = requests.request("POST", url, headers=headers, data=payload, files=files)
    message = response.json()
    # if resp.status_code == 200:
    #     message = resp.json()
    #print "message", message
    return message

# 执行工具
def tool_exec(relatedToolId, vId, instanceId):
    HEADERS = {"user": "easyops",
                   "org": str(EASYOPS_ORG),
                   "Content-Type": "application/json",
                   }
    url = "http://{}:8181/tools/execution".format(tool_ip)
    res_params = {
      "toolId": relatedToolId,
      "vId": vId,
      "windowsOnlyActiveSession": False,
      "batchStrategy": {
        "batchNum": 0,
        "batchInterval": 0,
        "failedStop": True,
        "enabled": False
      },
      "execUser": "root",
      "inputs": {
        "cmdbInstanceType": "cmdbInstanceFilterForm",
        "agentType": "cmdbInstanceFilterForm",
        "cmdbInstanceFilterForm": {
          "objectId": "HOST",
          "instances": {
            "type": "constant",
            "query": {
              "instanceId": {
                "$in": [
                  instanceId
                ]
              }
            }
          }
        }
      }
    }
    resp = requests.post(url=url, headers=HEADERS, json=res_params, timeout=60)
    message = resp.json()
    # if resp.status_code == 200:
    #     message = resp.json()
    return message


def host_olap(instanceId, starttime, endtime):
    HEADERS = {"user": "easyops",
               "org": str(EASYOPS_ORG),
               "Content-Type": "application/json",
               }
    url = "http://{}:8152/api/v1/data_exchange/olap".format(data_exchange_ip)
    res_params = {
        "model": "easyops.HOST",
        "dims": [
            "instanceId"
        ],
        "measures": [
            {
                "name": "system_cpu_total_norm_pct",
                "function": {
                    "expression": "max",
                    "args": [
                        "system_cpu_total_norm_pct"
                    ]
                }
            },
            {
                "name": "system_filesystem_used_pct",
                "function": {
                    "expression": "max",
                    "args": [
                        "system_filesystem_used_pct"
                    ]
                }
            },
            {
                "name": "system_memory_actual_used_pct",
                "function": {
                    "expression": "max",
                    "args": [
                        "system_memory_actual_used_pct"
                    ]
                }
            }
        ],
        "filters": [
            {
                "name": "instanceId",
                "operator": "in",
                "value": [

                    instanceId
                ]
            },
            {
                "name": "time",
                "operator": ">=",
                "value": starttime
            },
            {
                "name": "time",
                "operator": "<=",
                "value": endtime
            }
        ],
        "displayName": True,
        "fillEmptyData": True
    }
    resp = requests.post(url=url, headers=HEADERS, json=res_params, timeout=60)
    message = resp.json()
    # if resp.status_code == 200:
    #     message = resp.json()
    return message


if __name__ == "__main__":
    # ip = os.popen("hostname -I | awk '{print $1}'").read().strip()
    ip = os.popen("/usr/local/easyops/deploy_init/tools/get_env.py common inner_ip").read().strip()
    cmdb_ip = os.popen(
        "/usr/local/easyops/ens_client/tools/get_all_service.py logic.cmdb.service | head -n 1 | awk '{print $2}'").read().strip()
    tool_ip = os.popen(
        "/usr/local/easyops/ens_client/tools/get_all_service.py logic.tool_service | head -n 1 | awk '{print $2}'").read().strip()
    data_exchange_ip = os.popen("/usr/local/easyops/ens_client/tools/get_all_service.py logic.data_exchange | head -n 1 | awk '{print $2}'").read().strip()
    EASYOPS_ORG = os.popen(
        "cat /usr/local/easyops/deploy_init/easy_env.ini | grep -e '^org' | grep -v '#' |awk '{print $3}'").read().strip()

    print "【api接口验证】"

    # 查询主机的instanceID,判断cmdb查询接口是否正常
    res_params = {
        "fields": [
            "hostname",
            "_agentStatus",
            "ip",
            "isSinglePower",
            "instanceId"
        ],
        "page": 1,
        "page_size": 20,
        "ignore_missing_field_error": True,
        "query": {
            "$and": [
                {
                    "$or": [
                        {
                            "ip": {
                                "$eq": ip
                            }
                        }
                    ]
                }
            ]
        }
    }

    resp_data = search_cmdb("HOST", res_params)


    if resp_data["code"] == 0:

        print "cmdb实例查询接口正常(查询实例接口成功)"

        if resp_data["data"]["list"]:

            instanceId = resp_data["data"]["list"][0]["instanceId"]
        else:
            print "cmdb实例查询接口正常(主机模型中未查询到{}这个IP的实例)".format(ip)
            exit(1)
    else:
        print "cmdb实例查询接口异常(调用{}:8079的cmdb 查询接口失败)".format(cmdb_ip)
        exit(1)

    time.sleep(random.randint(1, 5))
    # 查询"巡检测试工具"工具,是否存在，获取toolId，vId，如果没有则创建，并获取toolId，vId
    res_params = {"fields":["relatedToolId","vId","instanceId","envType"],"page":1,"page_size":20,"ignore_missing_field_error":True,"query":{"$and":[{"$or":[{"relatedToolId":{"$eq":"1dddb6dd8e49a47e5983a0363824faed"}}]},{"$or":[{"vId":{"$eq":"7cb4437ea2fc2ed38bbe6da90557dd93"}}]},{"$or":[{"delete_me":{"$eq":False}}]}]}}
    resp_data = search_cmdb("_TOOL_VERSION@EASYOPS", res_params)

    if resp_data["code"] == 0:

        if resp_data["data"]["list"]:

            relatedToolId = resp_data["data"]["list"][0]["relatedToolId"]
            vId = resp_data["data"]["list"][0]["vId"]
            envtype = resp_data["data"]["list"][0]["envType"]
            # 修改工具版本为生产版本
            if envtype != "production":
                resp_data = import_cmdb()
                if resp_data["code"] != 0:
                    print "更改工具环境类型失败，可能导致工具执行失败"
        else:
            #print "工具模型中未查询到巡检测试工具的实例"

            # 导入工具
            resp_data = import_tool()
            #print resp_data
            if resp_data["code"] == 0:
                # 修改工具为生产版本
                resp = import_cmdb()
                if resp["code"] != 0:
                    print  "更改工具环境类型失败，可能导致工具执行失"
            else:
                print "更改工具环境类型失败，可能导致工具执行失"
            # if resp_data["code"] == 0:
            #     relatedToolId = resp_data["data"]["toolId"]
            #     vId = resp_data["data"]["vId"]
            # else:
            #     print "调用工具创建接口异常(创建工具失败)"

        # 执行工具验证是否正常
        try:
            resp_data = tool_exec("1dddb6dd8e49a47e5983a0363824faed", "7cb4437ea2fc2ed38bbe6da90557dd93", instanceId)
            if resp_data["code"] == 0:
                print "调用工具执行接口正常({}执行工具正常)".format(ip)
            else:
                print "调用工具执行接口异常({}执行工具返回码不为0)".format(ip)
        except:
            print "调用工具执行接口异常({}执行工具报错)".format(ip)

    else:
        print "cmdb实例查询接口异常(调用{}:8079的cmdb查询工具版本失败)".format(cmdb_ip)





    # 查询olap接口数据是否正常
    endtime = time.time()
    starttime = endtime -600
    try:
        resp_data = host_olap(instanceId, starttime, endtime)
        if resp_data["data"]["total"]:
            print "调用监控olap接口正常({}大禹监控数据正常)".format(ip)
        else:
            print "调用监控olap接口异常({}大禹监控数据异常)".format(ip)
    except:
        print "调用监控olap接口异常({}接口调用报错了)".format(ip)
