
#!/bin/bash
keyword="scheduler_service"
cpu_threshold=90
mem_threshold=60

function check_app_cpu(){
     cpu_usge=$( ps aux | grep $keyword | grep -vP grep | sort -n -k 3 | tail -1| awk '{print $3}')
	cpu_usge_int=`echo ${cpu_usge%.*}`
        if [[ $cpu_usge_int -gt $cpu_threshold  ]];then
                echo -e "cpu使用率异常(\033[31m$cpu_usge%\033[0m);"
        else
                echo -e "cpu使用率正常(\033[32m$cpu_usge%\033[0m);"
        fi
}


function check_app_mem(){
     mem_usge=$( ps aux | grep $keyword | grep -vP grep | sort -n -k 4 | tail -1| awk '{print $4}')
	mem_usge_int=`echo ${mem_usge%.*}`
        if [[ $mem_usge_int -gt $mem_threshold ]];then
                echo -e "内存使用率异常(\033[31m$mem_usge%\033[0m)"
        else
                echo -e "内存使用率正常(\033[32m$mem_usge%\033[0m);"
        fi
}



# Logic Operation
function main() {
        # 可以进入相关目录才去检查
        cd /usr/local/easyops/$keyword  >/dev/null 2>&1

        if [[ $? -eq 0 ]];then
            status=`easyops status /usr/local/easyops/$keyword | grep "not a valid package\|status:"`
                printf "%-10s%-10s\n" "$keyword检查结果: "
                        # 状态为ok并且start的则进行CPU内存判断
                        if [[ $status =~ "ok" ]] && [[ $status =~ "started" ]]; then

                                echo -e $(check_app_cpu)$(check_app_mem)" 组件健康状态正常(\033[32m状态为ok\033[0m);"
                        elif [[ $status =~ "current path is not a valid package" ]]; then
                                echo -e "组件健康状态正常(\033[32m该目录是一个未easyops init后的目录，不需要关注\033[0m);"
                        elif [[ $status =~ "ok" ]] && [[ $status =~ "stopped" ]]; then

                                echo -e "组件健康状态异常，status为(\033[31mok stopped状态是人工停止的状态，可以忽略),请确
认;"


                        else
                                echo -e "组件健康状态异常，status为(\033[31m$status\033[0m),请确认。"
                        fi

        fi

}

main
exit $?
