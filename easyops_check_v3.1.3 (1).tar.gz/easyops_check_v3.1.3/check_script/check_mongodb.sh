#!/bin/bash
INSTALL_PATH="/usr/local/easyops"
MONGODB="$INSTALL_PATH/mongodb/bin/mongo"
DATA_DIR="$INSTALL_PATH/mongodb/data"
LOG_DIR="$INSTALL_PATH/mongodb/log"
# mongo 端口
PORT=${1:-27017}
# 登陆数据库
INPUT_DBNAME=${2:-"admin"}
# 显示慢查询语句的数量
INPUT_NUM=${3:-5}

keyword="mongod"
process_name="mongod"
DIR="/usr/local/easyops/mongodb"
cpu_threshold=300
mem_threshold=60

# 自带变量
#MONGODB_DATA_IP="10.0.19.37 10.0.19.38"
#MONGODB_ARBITER_IP="10.0.19.36"
#MONGODB_PRIMARY_NODE="10.0.19.37"    
#COMMON_LOCAL_IP="10.0.19.37"
ENV_INI="/usr/local/easyops/deploy_init/easy_env.ini"
# 加载配置文件
function load_env_config() {
    # 读取 ${ENV_INI} 所配置的环境配置文件，转化格式为'GroupName_Key="Value"'，然后export配置为环境变量提供子进程使用
    while read conf
    do
       eval "export ${conf}"
    done <<< $(grep -vP "(^\s*#)|(^\s*$)" ${ENV_INI}|awk -F " *= *" '{
                                                            match($1,"^\\[(.*)\\]", a);
                                                            if(a[1]){
                                                            group = toupper(a[1]);
                                                            next
                                                            }
                                                        }
                                                        $1!=""{
                                                            gsub("\\.","_",$1);
                                                            gsub("#.*","",$2);
                                                            gsub("\"","",$2);
                                                            print group"_"toupper($1)"=\""$2"\""
                                                        }'
                                                        )
}


# Base db operation
# 单机环境直接备份，集群环境: 从从库进行备份，先判断哪台机器是从库，然后在进行备份
function isCluster() {
    #获取集群配置
    cluster=$(/usr/local/easyops/deploy_init/tools/get_env.py DEFAULT is_cluster)
    if [[ $? -ne 0 ]]; then
        echo "/usr/local/easyops/deploy_init/tools/get_env.py DEFAULT is_cluster failed"
        exit 1
    fi
    echo $cluster
}

function check_primary(){
	/usr/local/easyops/mongodb/bin/mongo --eval "printjson(db.isMaster())" | grep "ismaster" | grep true  >/dev/null 2>&1
    if [[ $? -eq 0 ]]; then
      return 0
    else
      return 1
    fi
}

function check_arbiter(){
    /usr/local/easyops/mongodb/bin/mongo --eval "printjson(db.isMaster())" | grep "arbiterOnly" | grep true  >/dev/null 2>&1
    if [[ $? -eq 0 ]]; then
      return 0
    else
      return 1
    fi
}



function check_secondary(){
    /usr/local/easyops/mongodb/bin/mongo --eval "printjson(db.isMaster())" | grep "secondary" | grep true  >/dev/null 2>&1
    if [[ $? -eq 0 ]]; then
      return 0
    else
      return 1
    fi
}
# arbiter server 的命令执行与其他 server 不一样
function mongodb_exec_cmd(){
    check_arbiter
    is_check=$?
    mongodb_password=`/usr/local/easyops/deploy_init/tools/get_env.py mongodb root_password`
    if [ $is_check -eq 0 ];then
        MONGODB_EXEC="${MONGODB} --eval"
    else
        MONGODB_EXEC="${MONGODB} ${COMMON_LOCAL_IP}:${PORT}/${INPUT_DBNAME} -uroot -p $mongodb_password --authenticationDatabase admin --eval"
    fi
}

function list_cluster_health(){
    $MONGODB_EXEC "printjson(rs.status())"
}

function list_db_size(){
    echo "show dbs" |${MONGODB} ${COMMON_LOCAL_IP}:${PORT}/${INPUT_DBNAME} -uroot -p $mongodb_password --authenticationDatabase admin | grep GB |sort -k 2 -n | tail -5
}


function list_uptime(){
    $MONGODB_EXEC 'db.runCommand({serverStatus:1})["uptime"]' | tail -n 1
}

function list_current_connections(){
    $MONGODB_EXEC 'db.runCommand({serverStatus:1})["connections"]["current"]' | tail -n 1
}

function list_available_connections(){
    $MONGODB_EXEC 'db.runCommand({serverStatus:1})["connections"]["available"]' | tail -n 1
}

function list_globalLock_currentQueue_total(){
    $MONGODB_EXEC 'printjson(db.runCommand({serverStatus:1})["globalLock"]["currentQueue"]["total"])' | tail -n 1
}

function list_globalLock_currentQueue_readers(){
    $MONGODB_EXEC 'printjson(db.runCommand({serverStatus:1})["globalLock"]["currentQueue"]["readers"])' | tail -n 1
}

function list_globalLock_activeClients_total(){
    $MONGODB_EXEC 'printjson(db.runCommand({serverStatus:1})["globalLock"]["activeClients"]["total"])' | tail -n 1
}

function list_opcounters_query(){
    $MONGODB_EXEC 'printjson(db.runCommand({serverStatus:1})["opcounters"]["query"])' | tail -n 1
}

function list_slow_level(){
    $MONGODB_EXEC 'printjson(db.getProfilingStatus()["was"])' |tail -n 1
}

function list_slow_limittime(){
    $MONGODB_EXEC 'printjson(db.getProfilingStatus()["slowms"])' |tail -n 1
}

function list_slow_max_num_sql(){
    cat "$LOG_DIR/mongod.log" | grep COMMAND|awk '{print $NF,"\t"$1,$2,$3,$4}' |sort -r -n | head -n $INPUT_NUM
    
}

function list_top_5_maxsize_db(){
    $MONGODB_EXEC 'printjson(db.getMongo().getDBs())' | tail -n +3 |awk -F 'sizeOnDisk' '/sizeOnDisk/{print $0}'| sort -n -r -k3| head -5
}



function get_status_info(){
    local status_code=0
    cluster_status="ok"
    # 判断集群健康状态
    cluster_info=$(list_cluster_health 2>/dev/null)
	
	is_ok=`echo "$cluster_info" | grep health|awk '{print $3}'`
	primary_ip=`echo "$cluster_info" | grep name | awk '{print $3}' | awk -F ":" '{print $1}' | sed -n "1p" |cut -b 2-`
	secondary_ip=`echo "$cluster_info" | grep name | awk '{print $3}' | awk -F ":" '{print $1}' | sed -n "2p" |cut -b 2-`
	arbiter_ip=`echo "$cluster_info" | grep name | awk '{print $3}' | awk -F ":" '{print $1}' | sed -n "3p" |cut -b 2-`
    if [[ $is_ok =~ "0" ]];then
        #printf "%-10s \033[31m%-10s\033[0m\n" "同步状态:" "异常"
        let status_code++
        cluster_status="error"
    #else
        #printf "%-10s \033[32m%-10s\033[0m\n" "同步状态:" "正常"
    fi

    # 慢查询。慢查询语句必须在 master 上执行
    # 慢查询开关。0表示关闭，1表示采集超过单位时间，2表示采集所有
    #echo
    #printf "%-10s\n" "开始慢查询检查:"
    #check_primary
    #is_primary=$?
    #if [ ${is_primary} -eq 0 ];then
        #printf "%-25s%-10s\n" "慢查询开关级别:" $(list_slow_level)
        #printf "%-25s%-10s\n" "慢时间单位(微妙):" "$(list_slow_limittime)ms"
        #printf "%-25s\n" "耗时最长的前5个慢查询:"
        #echo -e "耗时\t\t执行时间"
        
    #    list_slow_max_num_sql
    #else
    #    slow_info="\033[31m%-20s\033[0m\n" "当slaveOk=false, 慢查询只能在 Primary 主机显示"
    #fi
    return ${status_code}
}



# Logic Operation
function check_mongodb_status() {
    load_env_config
    # database
    #printf "%-10s%-10s\n" "Primary IP:" $MONGODB_PRIMARY_NODE
    #printf "%-10s%-10s\n" "Arbiter IP:" $MONGODB_ARBITER_IP
    #echo  "Data IP:" $MONGODB_DATA_IP
    # 确定执行脚本
    mongodb_exec_cmd

    # 运行时间
    #printf "%-25s%-10s\n" "启动时间(秒):" $(list_uptime)
    # 当前正在使用的连接数
    #printf "%-25s%-10s\n" "当前连接数:" $(list_current_connections)
    # 当前总连接数，包括未使用的
    #printf "%-25s%-10s\n" "可用连接数:" $(list_available_connections)
    # 操作的总数排队等待锁
    #printf "%-28s%-10s\n" "队列等待锁总数:" $(list_globalLock_currentQueue_total)
    #printf "%-27s%-10s\n" "队列等待读锁:" $(list_globalLock_currentQueue_readers)
    #printf "%-28s%-10s\n" "全局读写连接数:" $(list_globalLock_activeClients_total)
    #printf "%-29s%-10s\n" "启动后的查询总数:" $(list_opcounters_query)

    # 主从状态及采集信息
    get_status_info
    
    status_code=$?
    #echo 

    return ${status_code}
}

cpu_threshold=90
mem_threshold=60
ens_name_list="data.mongodb"
function check_ens(){
    name_service_status="(\033[32m正常\033[0m);"
    for ens_name in $ens_name_list
    do
        /usr/local/easyops/ens_client/tools/get_all_service.py $ens_name > /dev/null
        if [ $? -ne 0 ];then
            name_service_status="(\033[31m异常\033[0m);"
            #echo "get name service error: $ens_name"
        fi
    done
}
function byte_unit_trans() {
    bytes=${1:?"bytes is empty"}
    echo ${bytes}|awk -v b=${bytes} 'b>1000000{print b/1024/1024"GB";next}b>1000{print b/1024"MB";next}{print b"KB"}'
}

function compare() {
    condition=$1
    [[ `echo $1|bc` -ge 1 ]] && return 0 || return 1
}


function check_app_cpu(){
    cpu_usge=$( ps aux | grep $keyword | grep -vP grep  | sort -n -k 3 | tail -1| awk '{print $3}')
    cpu_usge_int=`echo ${cpu_usge%.*}`
    if [[ $cpu_usge_int -gt $cpu_threshold  ]];then
        echo -e "cpu使用率异常(\033[31m$cpu_usge%\033[0m);"
    else
        echo -e "cpu使用率正常(\033[32m$cpu_usge%\033[0m);"
    fi
}


function check_app_mem(){
    mem_usge=$( ps aux | grep $keyword | grep -vP grep | sort -n -k 4 | tail -1 | awk '{print $4}')
    mem_usge_int=`echo ${mem_usge%.*}`
    if [[ $mem_usge_int -gt $mem_threshold ]];then
        echo -e "内存使用率异常(\033[31m$mem_usge%\033[0m)"
    else
         echo -e "内存使用率正常(\033[32m$mem_usge%\033[0m);"
    fi
}

function check_slow_num(){
    mongodb_slow_num=`cat $LOG_DIR/mongod.log | grep slow|wc -l`
}

function check_app_health(){
    easyops status /usr/local/easyops/mongodb | grep "\[ok\]" > /dev/null 
    if [[ $? -eq 0 ]];then
        #echo -e "组件健康状态正常(\033[32mok\033[0m);"
        process_status="(\033[32mok\033[0m);"
    else
        echo -e "组件健康状态异常(\033[31merror\033[0m);"
        process_status="(\033[31merror\033[0m);"
    fi  
}

function check_top10_collection(){
   /usr/local/easyops/mongodb/bin/mongo -u root -p ` /usr/local/easyops/deploy_init/tools/get_env.py mongodb root_password` --authenticationDatabase admin --quiet --eval 'db.getMongo().setSlaveOk();db.getMongo().getDBNames().forEach(function(dbName) {
	if (dbName !== "local" && dbName !== "admin"  && dbName !== "config") {
     	var collections = db.getSiblingDB(dbName).getCollectionNames();
    	 collections.forEach(function(collection) {
        	 var stats = db.getSiblingDB(dbName).getCollection(collection).stats();
         	if (stats["count"] > 500000) {
         		var storageSizeInGB = (stats["storageSize"] / 1024 / 1024 / 1024).toFixed(2);
                        print("("+dbName + "." + collection + "文档数量: " + stats["count"] +", 占用物理磁盘空间:" + storageSizeInGB + "GB)");
        	}
     	});
     }
   });' | grep -v "WARNING"  | sort -rn -k2 | head -n 10 2>/dev/null

}

# Logic Operation
function main() {
        # 可以进入相关目录才去检查
        cd /usr/local/easyops/mongodb  >/dev/null 2>&1

        if [[ $? -eq 0 ]];then
            status=`easyops status /usr/local/easyops/mongodb | grep "not a valid package\|status:"`
                printf "%-10s%-10s\n" "$keyword检查结果: "
                        # 状态为ok并且start的则进行CPU内存判断
                        if [[ $status =~ "ok" ]] && [[ $status =~ "started" ]]; then
				check_ens
    				check_app_health
    				check_mongodb_status
    				check_slow_num
        			get_status_info
    				echo  -e "名字服务：$name_service_status $(check_app_cpu)$(check_app_mem) 组件健康状态：$process_status 当前连接数：($(list_current_connections));"
    				check_primary
    				is_primary=$?
    				if [ ${is_primary} -eq 0 ];then
                			get_status_info
                			echo -e "集群状态：$cluster_status,     primary是$primary_ip, secondary是$secondary_ip, arbiter是$arbiter_ip, rs_status($cluster_status);"
                			echo
        				#printf "%-25s\n" "耗时最长的前5个慢查询:"
        				#echo -e "耗时\t\t执行时间"
        				#list_slow_max_num_sql
                			echo -e "\n\033[32mtop5\033[0m的DB大小:"
                			list_db_size
    				else
       					echo "慢查询和集群状态,请在 Primary 主机查看"
    				fi
                               
                                # 在单机机器或者从库上获取top10 的collection
                                if [[ $(isCluster) == 'false' ]]; then
                                   echo -e "\n\033[32m大于50w的top10\033[0m的集合大小:"
			           check_top10_collection	

                                else
                                   check_secondary
                                   is_secondary=$?
                                   if [ ${is_secondary} -eq 0 ];then
                                      echo -e "\n\033[32m大于50W的top10\033[0m的集合大小:"
                                      check_top10_collection
                                   else
                                      echo "【mongodb的top10 的collection查询在从库执行，本节点不是从库，请到从库查看】"

                                   fi
                                 fi
                        elif [[ $status =~ "current path is not a valid package" ]]; then
                                echo -e "组件健康状态正常(\033[32m该目录是一个未easyops init后的目录，不需要关注\033[0m);"
                        elif [[ $status =~ "ok" ]] && [[ $status =~ "stopped" ]]; then

                                echo -e "组件健康状态异常，status为(\033[31mok stopped状态是人工停止的状态，可以忽略),请确
认;"

                        else
                                echo -e "组件健康状态异常，status为(\033[31m$status\033[0m),请确认。"
                        fi

        fi

}

main
exit $?
